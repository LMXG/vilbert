This folder contains modified coco-caption evaluation, which is downloaded from https://github.com/tylin/coco-caption.git
and refEvaluation which is to be called by the refer algorithm.

More specifically, this folder contains:
1. bleu/
2. cider/
3. meteor/
4. rouge/
5. tokenizer/
6. __init__.py
7. refEvaluation.py
